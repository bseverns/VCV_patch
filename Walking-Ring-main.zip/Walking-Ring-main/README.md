# Walking-Ring
Lorre-Mill Walking Ring PCB's Designed by crucFX

![WALKING RING1](https://user-images.githubusercontent.com/65085164/108943256-0b8fc500-761e-11eb-9ccf-6df4a89f6f06.jpg)
